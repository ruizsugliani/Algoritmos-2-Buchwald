#include <stdlib.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include "pila.h"
//Definición de los struct nodo y cola proporcionados por la cátedra.

typedef struct nodo {
    void* dato;
    struct nodo* prox;
} nodo_t;

typedef struct cola {
    nodo_t* prim;
    nodo_t* ult;
} cola_t;

// Definición de nodo_crear proporcionado por la cátedra.
nodo_t* nodo_crear(void* valor) {
    nodo_t* nodo = malloc(sizeof(nodo_t));
    if (nodo == NULL) {
        free(nodo);
        return NULL;
    }
    nodo->dato = valor;
    nodo->prox = NULL;
    return nodo;
}

/* *****************************************************************
 *                    PRIMITIVAS DE LA COLA
 * *****************************************************************/

cola_t *cola_crear(void) {
    cola_t *cola = malloc(sizeof(cola_t));
    if (cola == NULL) return NULL;
    cola->prim = NULL;
    cola->ult = NULL;
    return cola;
}

bool cola_esta_vacia(const cola_t *cola) {
    return cola->prim == NULL;
}

void *cola_ver_primero(const cola_t *cola) {
    if (cola_esta_vacia(cola)) return NULL;
    return cola->prim->dato;
}

bool cola_encolar(cola_t *cola, void *valor) {
    nodo_t *nodo = nodo_crear(valor);
    if (nodo == NULL) return false;
    if (cola_esta_vacia(cola)) {
        cola->prim = nodo;
        cola->ult = nodo;
        return true;
    }
    cola->ult->prox = nodo;
    cola->ult = nodo;
    return true;
}

void *cola_desencolar(cola_t *cola) {
    if (cola_esta_vacia(cola)) return NULL;
    void* dato = cola->prim->dato;
    nodo_t* nodo_ant = cola->prim;
    cola->prim = nodo_ant->prox;
    free(nodo_ant);
    return dato;
}

void cola_destruir(cola_t *cola, void (*destruir_dato)(void *)) {
    while (!cola_esta_vacia(cola)) {
        void* dato = cola_desencolar(cola);
        if (destruir_dato) destruir_dato(dato); 
    }
    free(cola);
}
//gcc -g -std=c99 -Wall -Wconversion -Wtype-limits -pedantic -Werror -o pruebas *.c
//valgrind --leak-check=full --track-origins=yes --show-reachable=yes ./pruebas