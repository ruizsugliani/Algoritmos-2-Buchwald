//1
size_t ab_sin_nietos(ab_t* ab) {
    if (!ab) return 0;
    size_t res_parcial;
    if (!ab->izq && !ab->der) res_parcial = 1;
    if (ab->izq) {
        if (!ab->izq->izq && !ab->izq->der) res_parcial = 1;
        else res_parcial = 0;
    }
    if (ab->der) {
        if (!ab->der->izq && !ab->der->der) res_parcial = 1;
        else res_parcial = 0;
    }
    return ab_sin_nietos(ab->izq) + ab_sin_nietos(ab->der) + res_parcial;
}
//  La complejidad es O(n), siendo n la cantidad de elementos que tenga el AB ya que debo recorrer todos los
// elementos verificando las condiciones para sumar dentro de la funcion. El tipo de recorrido es preorder porque
// primero observo las condiciones del elemento actual y luego repito la operación , primero para el hijo izq y luego para
// el hijo der.

//5
bool aplicar_selectivo(const hash_t* hash, int k, void (*aplicar)(void* dato)) {
    if (k > hash->capacidad) return false;
    int contador = 0;
    if (!iter) return NULL;

    for (int i = 0; contador < k; i++) {
        if (hash->tabla[i]) {
            lista_iter_t* iter = lista_iter_crear(hash->tabla[i]);
            while (!lista_iter_al_final(iter)) {
                hash_campo_t* campo_actual = lista_iter_ver_actual(iter);
                campo_actual->valor = aplicar(campo_actual->valor);
                lista_iter_avanzar(iter);
                contador++;
            }
            lista_iter_destruir(iter);
        }
    }
    return true;
}
//La complejidad es O(k) siendo k la cantidad de aplicaciones que se deban hacer sobre las claves del diccionario.