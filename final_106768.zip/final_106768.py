# Utiliza un diccionario/hash para poder (en tiempo constante) saber si el cambio de letra
# no deriva en un caso donde se debe devolver False. Por ende la complejidad es O(n)
# siendo n las longitudes de ambas cadenas (la misma en caso de poder compararlas), 
# aparte de sumarse las operaciones O(1) de los diccionarios, por ende, finalmente la complejidad es O(n)
def cadenas_isomorficas(cadena_x, cadena_y):
    if len(cadena_x) != len(cadena_y):
        return False
    cambios = dict()
    for c in range(len(cadena_x)):
        #Entra a la condicion si la letra actual ya tiene un cambio asignado y no es la misma letra que veo en la otra palabra.
        if cadena_x[c] in cambios and cambios[cadena_x[c]] != cadena_y[c]:
            return False
        if cadena_y[c] in cambios and cambios[cadena_y[c]] != cadena_x[c]:
            return False
        cambios[cadena_x[c]] = cadena_y[c]
        cambios[cadena_y[c]] = cadena_x[c]
    return True

def encontrar_contagiados(grupo, inicio, fin, positivos):
    '''
    Toma por parámetros un grupo (array de personas donde una esta contagiada) , inicio (indice inicial del array),
    fin (indice final del array) y positivos, un set o lista donde se agregaran quienes 
    dieron positivo. 
    '''
    if inicio == fin:
        #Si se llego al punto que solo hay una persona en el grupo entonces esta persona es la contagiada.
        positivos.add(grupo[inicio])
        return positivos
    
    medio = (inicio + fin) // 2
    lado_izq = grupo[inicio: medio]
    lado_der = grupo[medio + 1: fin]
    if pcr(lado_izq):
        encontrar_contagiados(grupo, inicio, medio, positivos)
    else:#Por descarte en el lado derecho esta el contagiado ya que el grupo inicial dio positivo al pcr
        encontrar_contagiados(grupo, medio + 1, fin, positivos)

#En esta funcion se parte la lista en 2 y se produce un solo llamado recursivo (para una u otra parte de la lista)
#Más operaciones O(1) por fuera de esto, por teo. maestro : A = 1 , B = 2, C = 1
# -> log_2(1) = 0 < 1 por ende la complejidad es O(n) y por ende en cuanto dicha notacion se estarían utilizando 
# N test.

def nuevo_flujo(red_residual, fuente, arista_modificada): #Aca supongo que arista_modificada es una tupla (v, w) 
    '''
    Recorro la red residual con un BFS ya que las aristas de la
    ultima red residual son aquellas donde va a estar la arista 
    con una capacidad aumentada.
    '''
    nuevo_flujo_max = 0
    visitados = set()
    q = Cola()
    visitados.add(fuente)
    q.encolar(fuente)
    while not q.esta_vacia():
        v = q.desencolar()
        for w in red_residual.adyacentes(v):
            if w not in visitados:
                visitados.add(w)
                q.encolar(w)
                if (v, w) == arista_modificada:
                    nuevo_flujo_max += red_residual.obtener_peso(arista_modificada)#Hago esto suponiendo que la arista no esta modificada en la red de flujo y solo se cual es
                else:
                    nuevo_flujo_max += red_residual.obtener_peso(v, w)

    return nuevo_flujo_max

#Finalmente la complejidad es O(v+e) ya que se aplica bfs, donde se recorre cada vertice y cada arista que sale del mismo.



