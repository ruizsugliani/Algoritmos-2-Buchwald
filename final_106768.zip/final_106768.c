//La complejidad de la primitiva es O(N) ya que recorre el arreglo dinamico
//de la pila una vez y hace operaciones O(1) en el proceso como guardar en el 
//arreglo resultante o comparar si esta en el rango de posiciones donde hacer lo anterior.
void** pila_medio(const pila_t* pila, size_t k) {
    size_t pos_inicio = (pila->cantidad / 2) - 1;
    size_t pos_final = pos_inicio + k - 1;
    size_t pos_arr = k - 1;

    void** res = malloc(sizeof(void*) * k);
    if (!res) return NULL;
    //Por si hay menos de K elementos en la pila , primero guardo NULL en todas las posiciones.
    //El cual a lo sumo es O(n) y por ende la complejidad sigue siendo la misma.
    for (size_t j = 0; j < k - 1; j++) {
        res[j] = NULL;
    }
    for (size_t i = 0; i < pila->cantidad; i++) {
        if (i >= pos_inicio && i <= pos_final) {
            res[pos_arr] = pila->datos[i];
            pos_arr--;
        }
    }
    return res;
}

